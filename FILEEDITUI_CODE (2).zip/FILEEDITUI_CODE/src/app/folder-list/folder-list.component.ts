import { Component, OnInit,EventEmitter, Output, Input,ViewChild,ElementRef } from '@angular/core';
import { DataService } from '../data.service';
import { Router } from '@angular/router';
import {MatButtonToggleModule} from '@angular/material/button-toggle';

@Component({
  selector: 'app-folder-list',
  templateUrl: './folder-list.component.html',
  styleUrls: ['./folder-list.component.scss']
})
export class FolderListComponent implements OnInit {

  printedOption: string;
  loadComponent:boolean;

  @ViewChild('group') versionInput: ElementRef;
  //selectedVersion:string = this.versionInput.nativeElement.value; 
  
  BankList: any = [];


 onValChange(value){
  console.log(value);
  this.loadAllBanks(value);
}

  ngOnInit() {
    
  }

  constructor(
    public dataService: DataService,
    public router:Router
  ){ }
  
   
  // @Input() selectedOption:string;
  selectedOption:string;
  //@Output() selectedBank : EventEmitter<string> =  new EventEmitter<string>();
   // Issues list
   loadAllBanks(value:String) {
  //  console.log(this.versionInput.nativeElement.value);
   // console.log('selectedVersion:- '+this.selectedVersion);
    return this.dataService.GetAllBanks(value).subscribe((data: {}) => {
      this.BankList = data;
    })
  }
  onChange()
  {  
      this.printedOption = this.selectedOption;
      // this.selectedBank.emit(this.selectedOption);
      this.loadComponent = true;
  }

}
