import { Component, OnInit, Input,OnChanges } from '@angular/core';
import { DataService } from '../data.service';
import { Property } from 'src/app/shared/property.model';

@Component({
  selector: 'app-search-files',
  templateUrl: './search-files.component.html',
  styleUrls: ['./search-files.component.scss']
})
export class SearchFilesComponent implements  OnChanges {

  constructor(public dataService: DataService) {}
  search :string='';

  ngOnInit(): void {
  }

  PropertySearchArray : Map<string, string> = null;
  @Input() searchParams: string;
  ngOnChanges() {
  console.log('in SearchFilesComponent:-'+this.searchParams)
  }
  searchProperty(){
    console.log(this.search)
    if(this.search){
    this.searchKeyword();
    //console.log(this.PropertySearchArray.size)
  }
  }
  searchKeyword(){
    console.log('In SearchKeyword');
    console.log(this.searchParams+"/"+this.search);
    return this.dataService.SearchKeyword(this.searchParams+"/"+this.search)
    .subscribe((data) => {
      console.log(data);
      this.PropertySearchArray = data;
      console.log('PropertySearchArray: '+data.toString()==='{}')
    })
  }
  

}
