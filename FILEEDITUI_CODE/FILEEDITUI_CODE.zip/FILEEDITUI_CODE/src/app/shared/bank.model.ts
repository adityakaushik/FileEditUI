export class Bank{
    name: string;
    }