
import { Property } from './property.model'; 

export interface GoArray {
      properties: Array<Property>;
}