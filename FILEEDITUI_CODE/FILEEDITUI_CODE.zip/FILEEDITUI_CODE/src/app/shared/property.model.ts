export interface Property{
    propertyName: string;  value: string
}