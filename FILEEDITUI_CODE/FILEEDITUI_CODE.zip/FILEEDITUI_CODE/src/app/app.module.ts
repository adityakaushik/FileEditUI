import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule }    from '@angular/common/http';
import { RouterModule} from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FileListComponent } from './file-list/file-list.component';
import { FolderListComponent } from './folder-list/folder-list.component';
import { FileDetailsComponent } from './file-list/file-details/file-details.component';
import { HeaderComponent } from './header/header.component';
import { DataService } from './data.service';
import { FormsModule } from '@angular/forms'; 
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import {MatButtonToggleModule} from '@angular/material/button-toggle';
import { SearchFilesComponent } from './search-files/search-files.component';

@NgModule({
  declarations: [
    AppComponent,
    FileListComponent,
    FolderListComponent,
    FileDetailsComponent,
   
    HeaderComponent,
   
    SearchFilesComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    CommonModule,
    FormsModule,
    MatButtonToggleModule,
    ReactiveFormsModule,
    AppRoutingModule,
    RouterModule.forRoot([
      { path: '', component: FolderListComponent },
      { path: 'PropertyFiles', component: FileListComponent },
      { path: 'Properties', component: FileDetailsComponent }
     // { path: 'Properties/:bankId', component: FileDetailsComponent }
    ])
  ],
  providers: [DataService],
  bootstrap: [AppComponent]
})
export class AppModule { }
