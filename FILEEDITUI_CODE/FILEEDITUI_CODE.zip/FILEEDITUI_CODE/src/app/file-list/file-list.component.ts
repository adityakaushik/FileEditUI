import { Component, OnInit ,Input, OnChanges,ViewChild,ElementRef} from '@angular/core';
import {HttpClient} from '@angular/common/http'
import { DataService } from '../data.service';

@Component({
  selector: 'app-file-list',
  templateUrl: './file-list.component.html',
  styleUrls: ['./file-list.component.scss']
})

export class FileListComponent implements  OnChanges {
  // @ViewChild('group')versionInput: ElementRef;
  // selectedVersion:string = this.versionInput.nativeElement.value;
  
  FileList: any;
  fileId: number =10;
  fileName: String="TestFile";
  allowButton=false;
  buttonclicked="No Event triggered yet."
  constructor(public dataService: DataService
    //,private http :HttpClient
    ) { 
    // setTimeout(() =>{
    //   this.allowButton=true;
    // },2000)
  }
  // @Input() selectedBank: string;
  clickEvent(){
   // this.buttonclicked="Event Triggered!!!!"
  }
  selectedBankFile:string;
  selectedFile:string;
  @Input() selectedOptionfile: string;
  loadProperties: boolean;

  ngOnChanges() {
    console.log('In');
    console.log(this.selectedOptionfile);
   // console.log('selectedVersion:- '+this.selectedVersion);
   // this.selectedBankFile=this.selectedOptionfile;
  if(this.selectedOptionfile){
    this.loadAllFileNames() 
  }
  }
 
  loadAllFileNames() {
    console.log('in loadAllFileNames');
    return this.dataService.LoadAllBankFiles(this.selectedOptionfile
      //this.selectedBank
      ).subscribe((data: {}) => {
      console.log(data);
      this.FileList = data;
    })
  }
  onFileSelectChange()
  {  
      //this.printedOption = this.selectedOption;
      console.log('onFileSelectChange');
      this.selectedFile=this.selectedOptionfile+'/'+this.selectedBankFile;
      console.log(this.selectedFile);
      // this.selectedBank.emit(this.selectedOption);
      this.loadProperties = true;
  }
  // onfetchFiles(){
  //   this.fetchproperties();
  // }
  // private fetchproperties(){
  //   this.http.get('http://localhost:8080/loadAllProperties').subscribe(posts =>{
  //     console.log(posts);
  //   })
  // }
}
