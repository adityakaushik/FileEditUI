import { Component, OnInit,OnChanges ,Input} from '@angular/core';
import { DataService } from '../../data.service';
import { Property } from 'src/app/shared/property.model';
import { GoArray } from 'src/app/shared/GoArray.model';

@Component({
  selector: 'app-file-details',
  templateUrl: './file-details.component.html',
  styleUrls: ['./file-details.component.scss']
})
export class FileDetailsComponent  implements  OnChanges {
  @Input() selectedOptionProperty: string;
 PropertyArray : Map<string, Property> = new Map<string, Property>();
 //PropertyList: any;
  constructor(public dataService: DataService) { }

  // ngOnInit() {
  //   this.LoadProperties();
  // }
  ngOnChanges() {
    this.PropertyArray=null;
    console.log('In file');
    console.log(this.selectedOptionProperty);
  if(this.selectedOptionProperty){
    this.LoadProperties();
  }
}
  LoadProperties(){
    console.log('In LoadProperties');
    return this.dataService.LoadFileDetails(this.selectedOptionProperty)
    .subscribe((data) => {
      console.log(data);
      this.PropertyArray = data;
      console.log(this.PropertyArray)
    })
  }
  
}