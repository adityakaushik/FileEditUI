import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Bank } from './shared/bank.model';
import { Property } from './shared/property.model'; 
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';

import { GoArray } from 'src/app/shared/GoArray.model';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  //PropertyArray: GoArray;
  PropertyArray : Map<string, string> = new Map<string, string>();
    // Base url
    baseurl = 'http://localhost:8080';

    constructor(private http: HttpClient) { }

    // Http Headers
    httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    }
    // GET
    GetAllBanks(version:String): Observable<Bank> {
      
      console.log("inGetAllBanks"+version);
    return this.http.get<Bank>(this.baseurl + '/listAllFolderFiles/'+version)
    .pipe(
      retry(1),
      catchError(this.errorHandl)
    )
  }
  
  LoadAllBankFiles(bankName:String): Observable<Bank> {
    bankName.replace(/\\/g, "/");
    return this.http.get<Bank>(this.baseurl + '/listAllFiles/'+bankName)
    .pipe(
      retry(1),
      catchError(this.errorHandl)
    )
  }

  LoadFileDetails(ext :string): Observable<any> {
    ext.replace(/\\/g, "/");
    return this.http.get<any>(this.baseurl + '/loadAllProperties/'+ ext)
    .pipe(
      retry(1),
      catchError(this.errorHandl)
    )
  }

  SearchKeyword(ext :string): Observable<any> {
    ext.replace(/\\/g, "/");
    return this.http.get<any>(this.baseurl + '/searchProperty/'+ ext)
    .pipe(
      retry(1),
      catchError(this.errorHandl)
    )
  }

  // Error handling
  errorHandl(error) {
    let errorMessage = '';
    if(error.error instanceof ErrorEvent) {
      // Get client-side error
      errorMessage = error.error.message;
    } else {
      // Get server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    console.log(errorMessage);
    return throwError(errorMessage);
 }


}
